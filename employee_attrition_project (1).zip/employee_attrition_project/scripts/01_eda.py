"""
01_eda.py
Employee Attrition Prediction & HR Analytics System
-----------------------------------------------------
Step 1: Load data, clean it, and run Exploratory Data Analysis (EDA).
Generates charts into outputs/charts/ and a cleaned CSV into data/.
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import os

sns.set_theme(style="whitegrid", palette="Set2")
plt.rcParams["figure.dpi"] = 110

BASE = "/home/claude/project"
DATA_IN = f"{BASE}/data/employee_attrition.csv"
CHART_DIR = f"{BASE}/outputs/charts"
os.makedirs(CHART_DIR, exist_ok=True)

# ---------------------------------------------------------
# 1. LOAD
# ---------------------------------------------------------
df = pd.read_csv(DATA_IN)
print("Raw shape:", df.shape)

# ---------------------------------------------------------
# 2. CLEAN
# ---------------------------------------------------------
# Drop constant / non-informative columns
drop_cols = [c for c in ["EmployeeCount", "Over18", "StandardHours", "EmployeeNumber"] if c in df.columns]
df_clean = df.drop(columns=drop_cols)

# Check for missing values / duplicates
missing = df_clean.isnull().sum().sum()
dupes = df_clean.duplicated().sum()
print(f"Missing values: {missing} | Duplicate rows: {dupes}")
df_clean = df_clean.drop_duplicates()

# Standardize target
df_clean["Attrition"] = df_clean["Attrition"].map({"Yes": 1, "No": 0})

# Save cleaned dataset (also used for Power BI dashboard)
df_clean.to_csv(f"{BASE}/data/employee_attrition_clean.csv", index=False)
print("Cleaned shape:", df_clean.shape)

attr_rate = df_clean["Attrition"].mean() * 100
print(f"Overall attrition rate: {attr_rate:.2f}%")

# ---------------------------------------------------------
# 3. EDA CHARTS
# ---------------------------------------------------------

# 3.1 Overall attrition distribution
fig, ax = plt.subplots(figsize=(5, 4))
counts = df_clean["Attrition"].value_counts().sort_index()
ax.bar(["Stayed", "Left"], counts.values, color=["#4C72B0", "#DD8452"])
for i, v in enumerate(counts.values):
    ax.text(i, v + 15, f"{v}\n({v/len(df_clean)*100:.1f}%)", ha="center", fontweight="bold")
ax.set_title("Overall Attrition Distribution")
ax.set_ylabel("Employees")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/01_attrition_overall.png")
plt.close()

# 3.2 Attrition by Department
fig, ax = plt.subplots(figsize=(6, 4))
dept_rate = df_clean.groupby("Department")["Attrition"].mean().sort_values(ascending=False) * 100
sns.barplot(x=dept_rate.values, y=dept_rate.index, ax=ax, hue=dept_rate.index, legend=False, palette="Set2")
ax.set_xlabel("Attrition Rate (%)")
ax.set_title("Attrition Rate by Department")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/02_attrition_by_department.png")
plt.close()

# 3.3 Attrition by Job Role
fig, ax = plt.subplots(figsize=(7, 5))
role_rate = df_clean.groupby("JobRole")["Attrition"].mean().sort_values(ascending=False) * 100
sns.barplot(x=role_rate.values, y=role_rate.index, ax=ax, hue=role_rate.index, legend=False, palette="flare")
ax.set_xlabel("Attrition Rate (%)")
ax.set_title("Attrition Rate by Job Role")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/03_attrition_by_jobrole.png")
plt.close()

# 3.4 OverTime vs Attrition
fig, ax = plt.subplots(figsize=(5, 4))
ot_rate = df_clean.groupby("OverTime")["Attrition"].mean() * 100
sns.barplot(x=ot_rate.index, y=ot_rate.values, ax=ax, hue=ot_rate.index, legend=False, palette=["#55A868", "#C44E52"])
ax.set_ylabel("Attrition Rate (%)")
ax.set_title("Attrition Rate: OverTime vs No OverTime")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/04_attrition_by_overtime.png")
plt.close()

# 3.5 Monthly Income distribution: stayed vs left
fig, ax = plt.subplots(figsize=(6, 4))
sns.kdeplot(data=df_clean, x="MonthlyIncome", hue="Attrition", fill=True, common_norm=False, ax=ax,
            palette={0: "#4C72B0", 1: "#DD8452"})
ax.set_title("Monthly Income Distribution: Stayed (0) vs Left (1)")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/05_income_distribution.png")
plt.close()

# 3.6 Job Satisfaction vs Attrition
fig, ax = plt.subplots(figsize=(5, 4))
js_rate = df_clean.groupby("JobSatisfaction")["Attrition"].mean() * 100
sns.barplot(x=js_rate.index, y=js_rate.values, ax=ax, color="#8172B2")
ax.set_xlabel("Job Satisfaction (1=Low, 4=High)")
ax.set_ylabel("Attrition Rate (%)")
ax.set_title("Attrition Rate by Job Satisfaction")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/06_attrition_by_jobsatisfaction.png")
plt.close()

# 3.7 Work-Life Balance vs Attrition
fig, ax = plt.subplots(figsize=(5, 4))
wlb_rate = df_clean.groupby("WorkLifeBalance")["Attrition"].mean() * 100
sns.barplot(x=wlb_rate.index, y=wlb_rate.values, ax=ax, color="#64B5CD")
ax.set_xlabel("Work-Life Balance (1=Bad, 4=Best)")
ax.set_ylabel("Attrition Rate (%)")
ax.set_title("Attrition Rate by Work-Life Balance")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/07_attrition_by_worklifebalance.png")
plt.close()

# 3.8 Years at Company vs Attrition
fig, ax = plt.subplots(figsize=(6, 4))
sns.boxplot(data=df_clean, x="Attrition", y="YearsAtCompany", hue="Attrition", legend=False,
            palette={0: "#4C72B0", 1: "#DD8452"}, ax=ax)
ax.set_xticks([0, 1])
ax.set_xticklabels(["Stayed", "Left"])
ax.set_title("Years at Company: Stayed vs Left")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/08_yearsatcompany_boxplot.png")
plt.close()

# 3.9 Promotion history vs Attrition
fig, ax = plt.subplots(figsize=(6, 4))
promo_rate = df_clean.groupby("YearsSinceLastPromotion")["Attrition"].mean() * 100
sns.lineplot(x=promo_rate.index, y=promo_rate.values, marker="o", ax=ax, color="#C44E52")
ax.set_xlabel("Years Since Last Promotion")
ax.set_ylabel("Attrition Rate (%)")
ax.set_title("Attrition Rate by Years Since Last Promotion")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/09_attrition_by_promotion.png")
plt.close()

# 3.10 Correlation heatmap (numeric features)
fig, ax = plt.subplots(figsize=(12, 10))
numeric_df = df_clean.select_dtypes(include=[np.number])
corr = numeric_df.corr()
sns.heatmap(corr, cmap="coolwarm", center=0, ax=ax, cbar_kws={"shrink": 0.7})
ax.set_title("Correlation Heatmap (Numeric Features)")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/10_correlation_heatmap.png")
plt.close()

# 3.11 Attrition vs age & salary band
df_clean["SalaryBand"] = pd.cut(df_clean["MonthlyIncome"],
                                  bins=[0, 3000, 6000, 10000, 20000],
                                  labels=["<3K", "3K-6K", "6K-10K", "10K+"])
fig, ax = plt.subplots(figsize=(6, 4))
sb_rate = df_clean.groupby("SalaryBand", observed=True)["Attrition"].mean() * 100
sns.barplot(x=sb_rate.index, y=sb_rate.values, ax=ax, color="#55A868")
ax.set_ylabel("Attrition Rate (%)")
ax.set_title("Attrition Rate by Salary Band")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/11_attrition_by_salaryband.png")
plt.close()

print("EDA complete. Charts saved to", CHART_DIR)

# Save a few key stats for the report
summary = {
    "total_employees": len(df_clean),
    "overall_attrition_rate_pct": round(attr_rate, 2),
    "highest_attrition_department": dept_rate.idxmax(),
    "highest_attrition_department_rate_pct": round(dept_rate.max(), 2),
    "highest_attrition_jobrole": role_rate.idxmax(),
    "highest_attrition_jobrole_rate_pct": round(role_rate.max(), 2),
    "overtime_attrition_rate_pct": round(ot_rate.get("Yes", 0), 2),
    "no_overtime_attrition_rate_pct": round(ot_rate.get("No", 0), 2),
}
import json
with open(f"{BASE}/outputs/eda_summary.json", "w") as f:
    json.dump(summary, f, indent=2)
print(json.dumps(summary, indent=2))
