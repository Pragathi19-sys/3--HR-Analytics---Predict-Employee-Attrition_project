"""
02_modeling.py
Employee Attrition Prediction & HR Analytics System
-----------------------------------------------------
Step 2: Train & evaluate Logistic Regression, Decision Tree, and
Random Forest classifiers. Saves metrics, confusion matrices, ROC
curves, and the best model (pickled) for use in the SHAP step.
"""

import pandas as pd
import numpy as np
import json
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, roc_auc_score, roc_curve,
                              confusion_matrix, classification_report)

BASE = "/home/claude/project"
CHART_DIR = f"{BASE}/outputs/charts"
MODEL_DIR = f"{BASE}/outputs/models"

df = pd.read_csv(f"{BASE}/data/employee_attrition_clean.csv")
df = df.drop(columns=["SalaryBand"], errors="ignore")

# ---------------------------------------------------------
# 1. ENCODE CATEGORICAL FEATURES
# ---------------------------------------------------------
target = "Attrition"
cat_cols = df.select_dtypes(include="object").columns.tolist()

encoders = {}
df_enc = df.copy()
for c in cat_cols:
    le = LabelEncoder()
    df_enc[c] = le.fit_transform(df_enc[c])
    encoders[c] = le

X = df_enc.drop(columns=[target])
y = df_enc[target]

feature_names = X.columns.tolist()

# ---------------------------------------------------------
# 2. TRAIN / TEST SPLIT
# ---------------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ---------------------------------------------------------
# 3. MODELS
# ---------------------------------------------------------
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42),
    "Decision Tree": DecisionTreeClassifier(max_depth=6, class_weight="balanced", random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=300, max_depth=8, class_weight="balanced", random_state=42),
}

results = {}
roc_data = {}

for name, model in models.items():
    if name == "Logistic Regression":
        model.fit(X_train_scaled, y_train)
        y_pred = model.predict(X_test_scaled)
        y_proba = model.predict_proba(X_test_scaled)[:, 1]
    else:
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        y_proba = model.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba)
    cm = confusion_matrix(y_test, y_pred)

    results[name] = {
        "accuracy": round(acc, 4),
        "precision": round(prec, 4),
        "recall": round(rec, 4),
        "f1_score": round(f1, 4),
        "roc_auc": round(auc, 4),
        "confusion_matrix": cm.tolist(),
    }

    fpr, tpr, _ = roc_curve(y_test, y_proba)
    roc_data[name] = (fpr, tpr, auc)

    # Confusion matrix plot
    fig, ax = plt.subplots(figsize=(4.5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                xticklabels=["Stayed", "Left"], yticklabels=["Stayed", "Left"])
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title(f"Confusion Matrix - {name}")
    plt.tight_layout()
    fname = name.lower().replace(" ", "_")
    plt.savefig(f"{CHART_DIR}/cm_{fname}.png")
    plt.close()

    print(f"\n{name}")
    print(f"  Accuracy: {acc:.4f}  Precision: {prec:.4f}  Recall: {rec:.4f}  F1: {f1:.4f}  ROC-AUC: {auc:.4f}")
    print(classification_report(y_test, y_pred, target_names=["Stayed", "Left"]))

# ---------------------------------------------------------
# 4. ROC CURVE COMPARISON
# ---------------------------------------------------------
fig, ax = plt.subplots(figsize=(6, 5))
for name, (fpr, tpr, auc) in roc_data.items():
    ax.plot(fpr, tpr, label=f"{name} (AUC={auc:.3f})")
ax.plot([0, 1], [0, 1], linestyle="--", color="gray")
ax.set_xlabel("False Positive Rate")
ax.set_ylabel("True Positive Rate")
ax.set_title("ROC Curve Comparison")
ax.legend()
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/roc_comparison.png")
plt.close()

# ---------------------------------------------------------
# 5. MODEL COMPARISON BAR CHART
# ---------------------------------------------------------
metrics_df = pd.DataFrame(results).T[["accuracy", "precision", "recall", "f1_score", "roc_auc"]]
fig, ax = plt.subplots(figsize=(9, 5))
metrics_df.plot(kind="bar", ax=ax, colormap="Set2")
ax.set_title("Model Performance Comparison")
ax.set_ylabel("Score")
ax.set_ylim(0, 1)
ax.legend(loc="lower right")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/model_comparison.png")
plt.close()

# ---------------------------------------------------------
# 6. FEATURE IMPORTANCE (Random Forest)
# ---------------------------------------------------------
rf_model = models["Random Forest"]
importances = pd.Series(rf_model.feature_importances_, index=feature_names).sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(7, 8))
sns.barplot(x=importances.head(15).values, y=importances.head(15).index, ax=ax,
            hue=importances.head(15).index, legend=False, palette="viridis")
ax.set_title("Top 15 Feature Importances - Random Forest")
ax.set_xlabel("Importance")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/feature_importance_rf.png")
plt.close()

# ---------------------------------------------------------
# 7. SAVE ARTIFACTS
# ---------------------------------------------------------
joblib.dump(rf_model, f"{MODEL_DIR}/random_forest_model.pkl")
joblib.dump(scaler, f"{MODEL_DIR}/scaler.pkl")
joblib.dump(encoders, f"{MODEL_DIR}/label_encoders.pkl")
joblib.dump(feature_names, f"{MODEL_DIR}/feature_names.pkl")
joblib.dump((X_train, X_test, y_train, y_test), f"{MODEL_DIR}/train_test_split.pkl")

with open(f"{BASE}/outputs/model_results.json", "w") as f:
    json.dump(results, f, indent=2)

best_model_name = max(results, key=lambda k: results[k]["roc_auc"])
print(f"\nBest model by ROC-AUC: {best_model_name} (AUC={results[best_model_name]['roc_auc']})")

print("\nModeling complete. Results saved to outputs/model_results.json")
