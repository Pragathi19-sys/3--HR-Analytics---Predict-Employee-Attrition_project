# Employee Attrition Prediction & HR Analytics System

## Contents
- data/employee_attrition.csv — raw IBM HR Analytics dataset (1,470 employees, 35 columns)
- data/employee_attrition_clean.csv — cleaned dataset used for modeling and Power BI (31 columns, encoded target)
- scripts/01_eda.py — data cleaning + exploratory data analysis, generates all EDA charts
- scripts/02_modeling.py — trains & evaluates Logistic Regression, Decision Tree, Random Forest
- scripts/03_shap_explainability.py — SHAP global + individual explanations for the Random Forest model
- charts/ — all generated PNG charts (EDA, model evaluation, SHAP)
- model_results.json, shap_top_drivers.json, eda_summary.json — machine-readable summary of results

## How to run
    pip install pandas numpy matplotlib seaborn scikit-learn shap joblib
    python scripts/01_eda.py
    python scripts/02_modeling.py
    python scripts/03_shap_explainability.py

Scripts default to a project root of /home/claude/project — edit the BASE variable
at the top of each script to point at wherever you place this folder.

## Deliverables (outside this folder)
- Employee_Attrition_Project_Report.docx — full written report (methodology, EDA findings,
  model comparison, SHAP analysis, Power BI build guide, retention recommendations)
- hr_attrition_dashboard.html — interactive, filterable analytics dashboard (published as a
  Claude artifact) — the Power BI-equivalent interactive layer, viewable in any browser
- data/employee_attrition_clean.csv — ready to import directly into Power BI / Tableau / Excel

## Key results
- Overall attrition rate: 16.12%
- Best model by ROC-AUC: Logistic Regression (AUC 0.807, recall 76.6%)
- Top SHAP drivers of attrition risk: OverTime, Age, MonthlyIncome, StockOptionLevel, YearsAtCompany
