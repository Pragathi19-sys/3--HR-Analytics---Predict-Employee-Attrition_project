"""
03_shap_explainability.py
Employee Attrition Prediction & HR Analytics System
-----------------------------------------------------
Step 3: Use SHAP (SHapley Additive exPlanations) on the Random Forest
model to explain (a) overall global feature contributions and
(b) individual employee predictions.
"""

import joblib
import shap
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

BASE = "/home/claude/project"
CHART_DIR = f"{BASE}/outputs/charts"
MODEL_DIR = f"{BASE}/outputs/models"

rf_model = joblib.load(f"{MODEL_DIR}/random_forest_model.pkl")
feature_names = joblib.load(f"{MODEL_DIR}/feature_names.pkl")
X_train, X_test, y_train, y_test = joblib.load(f"{MODEL_DIR}/train_test_split.pkl")

# ---------------------------------------------------------
# 1. BUILD SHAP EXPLAINER (TreeExplainer is fast + exact for RF)
# ---------------------------------------------------------
explainer = shap.TreeExplainer(rf_model)
shap_values = explainer.shap_values(X_test)

# shap_values can be a list [class0, class1] for older SHAP/sklearn RF outputs,
# or a single 3D array (n_samples, n_features, n_classes) for newer versions.
if isinstance(shap_values, list):
    shap_values_pos = shap_values[1]
elif shap_values.ndim == 3:
    shap_values_pos = shap_values[:, :, 1]
else:
    shap_values_pos = shap_values

# ---------------------------------------------------------
# 2. GLOBAL EXPLANATION - SUMMARY (BEESWARM) PLOT
# ---------------------------------------------------------
plt.figure(figsize=(9, 8))
shap.summary_plot(shap_values_pos, X_test, feature_names=feature_names, show=False)
plt.title("SHAP Summary Plot — Global Feature Impact on Attrition Risk")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/shap_summary_beeswarm.png", bbox_inches="tight")
plt.close()

# ---------------------------------------------------------
# 3. GLOBAL EXPLANATION - MEAN |SHAP| BAR PLOT
# ---------------------------------------------------------
plt.figure(figsize=(8, 8))
shap.summary_plot(shap_values_pos, X_test, feature_names=feature_names, plot_type="bar", show=False)
plt.title("Mean |SHAP Value| — Top Attrition Drivers")
plt.tight_layout()
plt.savefig(f"{CHART_DIR}/shap_bar_importance.png", bbox_inches="tight")
plt.close()

# ---------------------------------------------------------
# 4. LOCAL EXPLANATION - INDIVIDUAL EMPLOYEE WATERFALL
# ---------------------------------------------------------
# Pick one employee predicted "high risk" (attrition=1) and one "low risk"
proba = rf_model.predict_proba(X_test)[:, 1]
high_risk_idx = int(np.argmax(proba))
low_risk_idx = int(np.argmin(proba))

expected_value = explainer.expected_value
if isinstance(expected_value, (list, np.ndarray)) and np.ndim(expected_value) > 0:
    expected_value = expected_value[1]

for label, idx in [("high_risk", high_risk_idx), ("low_risk", low_risk_idx)]:
    exp = shap.Explanation(
        values=shap_values_pos[idx],
        base_values=expected_value,
        data=X_test.iloc[idx].values,
        feature_names=feature_names,
    )
    plt.figure(figsize=(8, 6))
    shap.plots.waterfall(exp, show=False, max_display=12)
    plt.title(f"SHAP Explanation — {'High' if label=='high_risk' else 'Low'} Risk Employee "
              f"(predicted attrition probability: {proba[idx]:.2f})")
    plt.tight_layout()
    plt.savefig(f"{CHART_DIR}/shap_waterfall_{label}.png", bbox_inches="tight")
    plt.close()

# ---------------------------------------------------------
# 5. SAVE TOP GLOBAL DRIVERS TO JSON FOR THE REPORT
# ---------------------------------------------------------
mean_abs_shap = np.abs(shap_values_pos).mean(axis=0)
top_drivers = pd.Series(mean_abs_shap, index=feature_names).sort_values(ascending=False).head(10)
top_drivers.to_json(f"{BASE}/outputs/shap_top_drivers.json", indent=2)

print("Top 10 SHAP attrition drivers:")
print(top_drivers)
print("\nSHAP explainability complete. Charts saved to", CHART_DIR)
